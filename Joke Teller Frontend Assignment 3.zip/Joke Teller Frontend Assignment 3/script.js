const heading = document.getElementById("jokeHeading");
const btn = document.getElementById("myBtn");
btn.addEventListener("click", jokeTeller)

async function jokeTeller(){
    let apiUrl = await fetch('https://icanhazdadjoke.com/',{
        headers: {
            accept: 'application/json'

        }
    });
    let data = await apiUrl.json();
    heading.innerHTML = data.joke;
}
jokeTeller()