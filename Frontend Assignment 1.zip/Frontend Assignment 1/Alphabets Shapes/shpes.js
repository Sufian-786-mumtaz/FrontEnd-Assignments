// Code for Alphabet S;
let mydiv = document.getElementById("mydiv"); 
for(let i=0; i<5; i++){
    for(let j = 0; j<5; j++){
        if(i==0 || i==2 || i==4 || j==0 && i<=2 || j==4 && i>=2){
            document.write("*&nbsp;");
        }
        else{
            document.write("&nbsp;&nbsp;&nbsp;")
        }
    }
    document.write("<br>");
}
document.write("<br>");
// Code for Alphabet U;
for(let i=0; i<5; i++){
    for(let j = 0; j<5; j++){
        if(i==4 || j==0 || j==4){
            document.write("*&nbsp;");
        }
        else{
            document.write("&nbsp;&nbsp;&nbsp;")
        }
    }
    document.write("<br>");
}

document.write("<br>");
// Code for Alphabet F;
for(let i=0; i<5; i++){
    for(let j = 0; j<5; j++){
        if(i==0 || i==2 || j==0){
            document.write("*&nbsp;");
        }
        else{
            document.write("&nbsp;&nbsp;&nbsp;")
        }
    }
    document.write("<br>");
}

document.write("<br>");
// Code for Alphabet I;
for(let i=0; i<5; i++){
    for(let j = 0; j<5; j++){
        if(i==0 || i==4 || j==2){
            document.write("*&nbsp;");
        }
        else{
            document.write("&nbsp;&nbsp;&nbsp;")
        }
    }
    document.write("<br>");
}

document.write("<br>");
// Code for Alphabet A;
for(let i=0; i<5; i++){
    for(let j = 0; j<5; j++){
        if(i==0 || i==2 || j==0 || j==4){
            document.write("*&nbsp;");
        }
        else{
            document.write("&nbsp;&nbsp;&nbsp;")
        }
    }
    document.write("<br>");
}
document.write("<br>");
// Code for Alphabet N;
for(let i=0; i<5; i++){
    for(let j = 0; j<5; j++){
        if(j==0 || j==4 || i==j ){
            document.write("*&nbsp;");
        }
        else{
            document.write("&nbsp;&nbsp;&nbsp;")
        }
    }
    document.write("<br>");
}


