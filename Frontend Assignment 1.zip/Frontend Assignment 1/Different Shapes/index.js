
let row = 5;
for(let i=1; i<=row; i++){
    for(j=1; j<=row; j++){
        document.write("*&nbsp;&nbsp;&nbsp");
    }
    document.write("<br>");
}

// code for Right Triangle
document.write("<br>");
for(let i = 0; i <= row; i++){
    for(let j = 0; j <= i; j++){
        document.write("*&nbsp;&nbsp;&nbsp");
    }
    document.write("<br>");
}
// code for Left Triangle
document.write("<br>");
for(let i = 0; i <= row; i++){
    for(let j = i; j <= row; j++){
        document.write("*&nbsp;&nbsp;&nbsp");
    }
    document.write("<br>");
}

document.write("<br>");
//combination of right and left 
for(let i = 0; i <= row; i++){
    for(let j = 0; j <= i; j++){
        document.write("*&nbsp;&nbsp;&nbsp");
    }
    document.write("<br>");
}
for(let i = 0; i <= row; i++){
    for(let j = i; j <= row; j++){
        document.write("*&nbsp;&nbsp;&nbsp");
    }
    document.write("<br>");
}

// left sided triangle
document.write("<br>");
for(let i = 0; i<=row; i++){
    for(let j = i; j<=row; j++){
        document.write("&nbsp;&nbsp;&nbsp;");
    } 
    for(let k = 1; k <= i; k++){
        document.write("*&nbsp;");
    }
    document.write("<br>");
}
document.write("<br>");

// Right sided triangle
for(let i = 0; i<=row; i++){
    for(let k = 1; k <= i; k++){
        document.write("&nbsp;&nbsp;&nbsp;");
    }
    for(let j = i; j<=row; j++){
        document.write("*&nbsp;");
    } 
    document.write("<br>");
}


// left sided triangle
document.write("<br>");
for(let i = 0; i<=row; i++){
    for(let j = i; j<=row; j++){
        document.write("&nbsp;&nbsp;&nbsp;");
    } 
    for(let k = 1; k <= i; k++){
        document.write("*&nbsp;");
    }
    document.write("<br>");
}

// Right sided triangle
for(let i = 0; i<=row; i++){
    for(let k = 1; k <= i; k++){
        document.write("&nbsp;&nbsp;&nbsp;");
    }
    for(let j = i; j<=row; j++){
        document.write("*&nbsp;");
    } 
    document.write("<br>");
}

// Hill pattern

for(let i =0; i<=row; i++){
    for(let j = i; j<=row; j++){
        document.write("&nbsp;&nbsp;&nbsp;")
    }
    for(let k = 1; k<=i; k++){
        document.write("*&nbsp;");
    }
    for(let h = 1; h<=i; h++){
        document.write("*&nbsp;");
    }
    document.write("<br>");
}
