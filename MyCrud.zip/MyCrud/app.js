const express = require("express");
const fs = require("fs");
const { listUsers, updatedUser, getUser, addUser, deleteUser} = require("./services");
const app = express();
app.use(express.json({extended:false}));
app.get("/", (req,res)=>{
    let users = listUsers();
    res.send(users);
});
app.get("/users/:Id", (req,res)=>{
    const {userId} = req.params;
    const user = getUser(userId);
    res.send(user);
})
app.post("/users", (req,res)=>{
    const user = req.body;
    const message = addUser(user)
    res.send(message);
})
app.put("/users/:userid", (req,res)=>{
    let users = listUsers();
    const id = req.params.userid;
    const data = req.body;
    const response = updatedUser(id,data);
    res.send(response);   
})
app.delete("users/:delId",(req,res)=>{
    const myid = req.params.delId;
    const del = deleteUser(myid);
    console.log(id);
    res.send(`your id: ${del} is deleted`);
})
app.listen(3000, ()=>{
    console.log("Hello i am listing at 9000 port")
}); 