const { json } = require("express");
const fs = require("fs");
const { format } = require("path");
let users = fs.readFileSync("users.json", "utf-8");
users = JSON.parse(users);

const listUsers = ()=>{
    return users;
}

const getUser = (userId)=>{
    userId = Number(userId);
    return users.find(user=> user.id === userId)
}
const addUser = (user)=>{
    user.unshif(user);
    fs.writeFileSync("users.json", JSON.stringify(user), "utf-8")
    return "User Successfully added";
}

const updatedUser = (id, newData)=>{
    let users = listUsers();
    let found = users.find((user)=>{
        return user.id == id;
    })
    for(const key in newData){
        found[key] = newData[key];
    }
    fs.writeFileSync("users.json", JSON.stringify(users), "utf-8")
    }
    const deleteUser = (id)=>{
        let users = listUsers();
        let deluser = users.filter((user)=>user.id != id)
        console.log(deluser);
        fs.writeFileSync("users.json", JSON.stringify(deluser), "utf-8");
    }
module.exports = {listUsers, updatedUser, getUser, addUser, deleteUser};