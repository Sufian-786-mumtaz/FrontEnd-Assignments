let hours = document.getElementById("hours");
let minuts = document.getElementById("minuts");
let seconds = document.getElementById("sec");
let session = document.getElementById("session");
function showClock(){
    let date = new Date();
    hours.innerHTML = date.getHours();
    minuts.innerHTML = date.getMinutes() + ":";
    seconds.innerHTML = date.getSeconds();
    if(hours.innerHTML >= 12){
        session.innerHTML = "PM";
    }else{
        session.innerHTML = "AM";
    }

    if(hours.innerHTML >=12){
        hours.innerHTML = hours.innerHTML - 12
    }
    if(hours.innerHTML == 0 && session.innerHTML == "PM"){
        hours.innerHTML = 12;
    }
    setTimeout(showClock, 1000);
}
showClock();